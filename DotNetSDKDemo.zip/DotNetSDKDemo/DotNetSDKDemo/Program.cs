﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace DotNetSDKDemo
{
    class Program
    {
        static void  Main(string[] args)
        {
            ContainersDemo.Run().Wait();
             //DatabasesDemo.Run().Wait();
           
            
            //QueryForDocuments().Wait();
        }

        private async static Task QueryForDocuments()
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var endPoint = config["CosmosEndPoint"];
            var masterKey = config["CosmosMasterKey"];

            using (var client = new CosmosClient(endPoint, masterKey)) 
            {
                var container = client.GetContainer("Families", "Families");

                var sql = "Select * From c WHERE ARRAY_LENGTH(c.kids) > 1";

                var iterator = container.GetItemQueryIterator<dynamic>(sql);

                var page = await iterator.ReadNextAsync();

                foreach (var item in page)
                {
                    Console.WriteLine($"Family {item.id} has {item.kids.Count} Children...");
                }

            }
        }
    }
}
